# SKILL.md
## Collaborative Development Ledger Skill

### name
collaborative_development_ledger

### description
此 Skill 用於在長期協作開發專案中，
結構化紀錄討論歷程、推理脈絡與決策演化，
以支援人類與 Agent 的後續回溯與理解。

### actions
- append_discussion
- link_to_prior
- mark_state
- extract_open_threads
- replay_reasoning
