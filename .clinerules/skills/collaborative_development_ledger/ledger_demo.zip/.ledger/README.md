# Collaborative Development Ledger (Demo)

This directory is a demo ledger for testing and onboarding purposes only.

- Do not treat this as authoritative project history
- Entries demonstrate the expected structure and semantics
- Copilot should follow append-only rules when operating on real projects
